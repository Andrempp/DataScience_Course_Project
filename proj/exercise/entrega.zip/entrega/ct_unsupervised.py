import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.naive_bayes import GaussianNB
import datapreprocessing as datapp, evaluation as eval, plot
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier

def unsupervised_statistics(df):
    data = df.copy()
    columns = ['Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology', 'Vertical_Distance_To_Hydrology'
        , 'Horizontal_Distance_To_Roadways', 'Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm',
               'Horizontal_Distance_To_Fire_Points',
               'y0', 'y1', 'y2', 'y3', 'y4', 'y5', 'y6', 'y7', 'y8', 'y9', 'y10', 'y11', 'y12', 'y13', 'y14', 'y15',
               'y16', 'y17', 'y18',
               'y19', 'y20', 'y21', 'y22', 'y23', 'y24', 'y25', 'y26', 'y27', 'y28', 'y29', 'y30', 'y31', 'y32', 'y33',
               'y34', 'y35',
               'y36', 'y37', 'y38', 'y39', 'y40', 'y41', 'y42', 'y43', 'Cover_Type']

    categoric = ['y0', 'y1', 'y2', 'y3', 'y4', 'y5', 'y6', 'y7', 'y8', 'y9', 'y10', 'y11', 'y12', 'y13', 'y14', 'y15',
                 'y16', 'y17', 'y18',
                 'y19', 'y20', 'y21', 'y22', 'y23', 'y24', 'y25', 'y26', 'y27', 'y28', 'y29', 'y30', 'y31', 'y32',
                 'y33', 'y34', 'y35',
                 'y36', 'y37', 'y38', 'y39', 'y40', 'y41', 'y42', 'y43']
    to_clf = 'Cover_Type'
    rs = 32
    accs = []

    ###########################################################
    y: np.ndarray = data[to_clf].values
    X: np.ndarray = data.drop(to_clf, axis=1).values
    X = X.astype("int")
    y = y.astype("int")
    ###########################################################
    select = SelectKBest(f_classif, k=10).fit(X, y)
    ind = select.get_support(indices=True)
    col = df.columns[ind].tolist()

    X_new = select.transform(X)
    dfk = pd.DataFrame(X_new, columns=col)

    ig = categoric + [to_clf]

    bins = list(range(3, 12))
    qdfs = []
    cdfs = []
    for b in bins:
        qdfs.append(eval.cut(dfk, b, categoric + [to_clf], cut="qcut"))
        cdfs.append(eval.cut(dfk, b, categoric + [to_clf], cut="cut"))
    # %%
    cat = ['Wilderness_Area1', 'Wilderness_Area4', 'Soil_Type3', 'Soil_Type10', 'Soil_Type38', 'Soil_Type39']
    # %%
    """
    al_dum_q = []
    al_dum_c = []
    for i in range(len(bins)):
        al_dum_q.append(qdfs[i][cat])
        qdfs[i] = qdfs[i].drop([cat], axis=1)
    """
    # %%
    dummy_qdfs = []
    dummy_cdfs = []
    for i in range(len(bins)):
        dummy_qdfs.append(eval.dummy(qdfs[i], categoric + [to_clf]))
        dummy_cdfs.append(eval.dummy(cdfs[i], categoric + [to_clf]))
    # %%
    dummy_qdfs[0].head()
    # %%
    fiq_q = []
    fiq_c = []
    for i in range(len(bins)):
        fiq_q.append(eval.freq_itemsets(dummy_qdfs[i], minpaterns=100))
        fiq_c.append(eval.freq_itemsets(dummy_cdfs[i], minpaterns=100))
    # %%
    rules_q = []
    rules_c = []
    for i in range(len(bins)):
        rules_q.append(eval.assoc_rules(fiq_q[i], orderby="lift", min_confidence=0.9).head(20))
        rules_c.append(eval.assoc_rules(fiq_c[i], orderby="lift", min_confidence=0.9).head(20))

    rules_qsup = []
    rules_csup = []
    for i in range(len(bins)):
        rules_qsup.append(eval.assoc_rules(fiq_q[i], orderby="support", min_confidence=0.9).head(20))
        rules_csup.append(eval.assoc_rules(fiq_c[i], orderby="support", min_confidence=0.9).head(20))

    # %%
    q_lifts = []
    c_lifts = []
    for i in range(len(bins)):
        q_lifts.append(rules_q[i]["lift"].mean())
        c_lifts.append(rules_c[i]["lift"].mean())

    q_sup = []
    c_sup = []
    for i in range(len(bins)):
        q_sup.append(rules_qsup[i]["support"].mean())
        c_sup.append(rules_csup[i]["support"].mean())

    print(
        "1. Pattern Minning:\n1.1 Preprocessing:\nSince there are no NaN, we don«t perform imputation.\nSince *{}* is "
        "too big to apply pattern minning, we perform SelectKBest to choose {} representative variables.\nWe then "
        "dummify with the bins {}".format(data.shape[0], 10, bins))