from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
import datapreprocessing as datapp, evaluation as eval, plot

def preprocessing_statistics(df):
    data = df.copy()
    data = data.astype("float")
    data["id"] = data["id"].astype("int")
    rs = 32
    to_clf = "class"
    categoric = ["gender", "id"]
    to_remove = ["id"]

    norms = [None, "minmax", "standard"]
    names = ["Gaussian NB", "Decision Tree", "Random Forest"]
    classifiers = [GaussianNB(), DecisionTreeClassifier(), RandomForestClassifier(n_estimators=10)]
    accs = []
    sensi = []
    for n in range(len(norms)):
        norm = norms[n]
        for clf in classifiers:
            datared = datapp.preprocess_alt(data, "class", normalization=norm, ignore_classes=categoric, as_df=True)
            acc, sens, cfm = eval.train_predict_kfold(datared, "class", clf, bal=None)
            accs.append(acc)
            sensi.append(sens)

    print("1. Normalization:\nVarious normalizations were tested using classifiers with default parameters.\n"
          "1.1 No normalization:\n{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}"
          "\t\tsensitivity:\t{}\n1.2 MinMax Normalization:\n"
          "{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}\t\tsensitivity:\t{}"
          "\n1.3 Standard Normalization:\n{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}\t\tsensitivity:\t{}"
          "\n{} accuracy:\t{}\t\tsensitivity:\t{}\n"
          .format(names[0], accs[0], sensi[0], names[1], accs[1],sensi[1], names[2], accs[2],sensi[2], names[0], accs[3],
                  sensi[3],names[1],accs[4],sensi[4],names[2],accs[5], sensi[5],names[0], accs[6],sensi[6], names[1],
                  accs[7], sensi[7],names[2],accs[8],sensi[8]))

    #####################################################################################
    normalization = "standard"
    balances = [None, "oversample", "smote"]
    classifiers = [GaussianNB(), DecisionTreeClassifier(), RandomForestClassifier()]
    names = ["Gaussian Naive Bayes", "Decision Tree", "Random Forest"]

    accs=[]
    sensi=[]
    for n in range(len(balances)):
        balance = balances[n]
        for clf in classifiers:
            datared = datapp.preprocess_alt(data, "class", normalization=normalization,
                                            ignore_classes=categoric, as_df=True)
            acc, sens, cfm = eval.train_predict_kfold(datared, "class", clf, bal=balance)
            accs.append(acc)
            sensi.append(sens)
    print("2. Balancing:\nVarious balancings were tested using classifiers with default parameters.\n"
          "2.1 No balancing:\n{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}"
          "\t\tsensitivity:\t{}\n2.2 Oversample balancing:\n"
          "{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}\t\tsensitivity:\t{}"
          "\n2.3 SMOTE balancing:\n{} accuracy:\t{}\t\tsensitivity:\t{}\n{} accuracy:\t{}\t\tsensitivity:\t{}"
          "\n{} accuracy:\t{}\t\tsensitivity:\t{}\n"
          .format(names[0], accs[0], sensi[0], names[1], accs[1],sensi[1], names[2], accs[2],sensi[2], names[0], accs[3],
                  sensi[3],names[1],accs[4],sensi[4],names[2],accs[5], sensi[5],names[0], accs[6],sensi[6], names[1],
                  accs[7], sensi[7],names[2],accs[8],sensi[8]))

