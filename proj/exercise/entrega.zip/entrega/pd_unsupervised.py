import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.naive_bayes import GaussianNB
import datapreprocessing as datapp, evaluation as eval, plot
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier

def unsupervised_statistics(df):
    data = df.copy()
    data = data.astype("float")
    data["id"] = data["id"].astype("int")
    to_clf = "class"
    categoric = ["gender", "id"]
    to_remove = ["id"]
    rs = 32
    accs = []
    sensi = []
    ###########################################################
    y: np.ndarray = data[to_clf].values
    X: np.ndarray = data.drop(to_clf, axis=1).values
    ###########################################################
    select = SelectKBest(f_classif, k=10).fit(X, y)
    ind = select.get_support(indices=True)
    col = df.columns[ind].tolist()

    X_new = select.transform(X)
    dfk = pd.DataFrame(X_new, columns=col)

    bins = list(range(3, 12))
    qdfs = []
    cdfs = []
    for b in bins:
        qdfs.append(eval.cut(dfk, b, ['class', 'id', 'gender'], cut="qcut"))
        cdfs.append(eval.cut(dfk, b, ['class', 'id', 'gender'], cut="cut"))

    dummy_qdfs = []
    dummy_cdfs = []
    for i in range(len(bins)):
        dummy_qdfs.append(eval.dummy(qdfs[i], ['class', 'id', 'gender']))
        dummy_cdfs.append(eval.dummy(cdfs[i], ['class', 'id', 'gender']))

    fiq_q = []
    fiq_c = []
    for i in range(len(bins)):
        fiq_q.append(eval.freq_itemsets(dummy_qdfs[i], minpaterns=100, verbose=False))
        fiq_c.append(eval.freq_itemsets(dummy_cdfs[i], minpaterns=100, verbose=False))

    rules_q = []
    rules_c = []
    for i in range(len(bins)):
        rules_q.append(eval.assoc_rules(fiq_q[i], orderby="lift", min_confidence=0.9).head(20))
        rules_c.append(eval.assoc_rules(fiq_c[i], orderby="lift", min_confidence=0.9).head(20))

    rules_qsup = []
    rules_csup = []
    for i in range(len(bins)):
        rules_qsup.append(eval.assoc_rules(fiq_q[i], orderby="support", min_confidence=0.9).head(20))
        rules_csup.append(eval.assoc_rules(fiq_c[i], orderby="support", min_confidence=0.9).head(20))


    q_lifts = []
    c_lifts = []
    for i in range(len(bins)):
        q_lifts.append(rules_q[i]["lift"].mean())
        c_lifts.append(rules_c[i]["lift"].mean())

    q_sup = []
    c_sup = []
    for i in range(len(bins)):
        q_sup.append(rules_qsup[i]["support"].mean())
        c_sup.append(rules_csup[i]["support"].mean())

    lvalues = {}
    lvalues["cut"] = c_lifts
    lvalues["qcut"] = q_lifts

    svalues = {}
    svalues["cut"] = c_sup
    svalues["qcut"] = q_sup

    print("1. Pattern Minning:\n1.1 Preprocessing:\nSince there are no NaN, we don«t perform imputation.\nSince *{}* is "
          "too big to apply pattern minning, we perform SelectKBest to choose {} representative variables.\nWe then "
          "dummify with the bins {}".format(data.shape[0], 10, bins))
