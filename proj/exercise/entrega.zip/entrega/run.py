import sys, pandas as pd
import pd_classif, ct_classif, pd_preprocessing, ct_preprocessing, pd_unsupervised, ct_unsupervised
import imports
def classification(source, df):
    if source == "PD":
        df["class"] = df["class"].astype("int")
        res = pd_classif.classification_statistics(df)
        return res
    elif source == "CT":
        res = ct_classif.classification_statistics(df)

def preprocessing(source, df):
    if source == "PD":
        df["class"] = df["class"].astype("int")
        res = pd_preprocessing.preprocessing_statistics(df)
        return res
    elif source == "CT":
        res = ct_preprocessing.preprocessing_statistics(df)

def unsupervised(source, df):
    if source == "PD":
        df["class"] = df["class"].astype("int")
        res = pd_unsupervised.unsupervised_statistics(df)
        return res
    elif source == "CT":
        res = ct_unsupervised.unsupervised_statistics(df)


def report(source, dataframe, task):
    if task == "classification\r":
        res = classification(source, dataframe)
        return res
    elif task == "preprocessing\r":
        res = preprocessing(source, dataframe)
    elif task == "unsupervised\r":
        res = unsupervised(source, dataframe)


def main():
    '''A: read arguments'''
    args = sys.stdin.readline().rstrip('\n').split(' ')
    n, source, task = int(args[0]), args[1], args[2]

    '''B: read dataset'''
    data, header = [], sys.stdin.readline().rstrip('\r\n').split(',')
    for i in range(n - 1):
        data.append(sys.stdin.readline().rstrip('\r\n').split(','))
    dataframe = pd.DataFrame(data, columns=header)
    '''C: output results'''
    print(report(source, dataframe, task))

if __name__ == '__main__':
    main()

