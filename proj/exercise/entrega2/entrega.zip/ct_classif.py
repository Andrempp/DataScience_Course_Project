import pandas as pd
from sklearn import metrics
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB, BernoulliNB
import datapreprocessing as datapp, evaluation as eval, plot
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier


def classification_statistics(df):
    data = df. copy()
    columns = ['Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology', 'Vertical_Distance_To_Hydrology'
        , 'Horizontal_Distance_To_Roadways', 'Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm',
               'Horizontal_Distance_To_Fire_Points',
               'y0','y1','y2','y3','y4','y5','y6','y7','y8','y9','y10','y11','y12','y13','y14','y15','y16','y17','y18',
               'y19','y20','y21','y22','y23','y24','y25','y26','y27','y28','y29','y30','y31','y32','y33','y34','y35',
               'y36','y37','y38','y39','y40','y41','y42','y43', 'Cover_Type']

    categoric = ['y0','y1','y2','y3','y4','y5','y6','y7','y8','y9','y10','y11','y12','y13','y14','y15','y16','y17','y18',
               'y19','y20','y21','y22','y23','y24','y25','y26','y27','y28','y29','y30','y31','y32','y33','y34','y35',
               'y36','y37','y38','y39','y40','y41','y42','y43']
    to_clf = 'Cover_Type'
    rs = 32
    accs=[]

    #Preprocessing decisions
    train_ratio = 0.7
    normalization = "standard"
    bal = "subsample"
    trnX, tstX, valX, trnY, tstY, valY = datapp.subsample_split(data, to_clf, categoric, normalization)
    trnY = trnY.astype("int")
    valY = valY.astype("int")
    tstY = tstY.astype("int")
    labels = pd.unique(data[to_clf].values).astype("int")

    print("1. Applied preprocessing to all classifiers:\nNormalization: *{}*.\nBalancing of the trainning "
          "sets using: *{} with the count of the class with less observations*.\n".format(normalization, bal))
    print("2. Classifiers:")
    #######################################################################################################
    #Naive Bayes
    nb = BernoulliNB()
    nb.fit(trnX, trnY)
    pred = nb.predict(tstX)
    acc = metrics.accuracy_score(tstY, pred)
    accs.append(acc)
    cfm = metrics.confusion_matrix(tstY, pred, labels)
    print("2.1 Naive Bayes")
    print("a) Parameterization: \nAfter experimenting, the default parameterization was used with the Bernoulli Naive"
          "Bayes.")
    print("b) Evaluation Metrics:\nAccuracy:{}\nConfusion Matrix:\n{}".format(acc, cfm))

    #######################################################################################################
    #KNN
    metric = "manhattan"
    n_neighbors = 3
    weight = "distance"

    knn = KNeighborsClassifier(n_neighbors=n_neighbors, metric=metric, weights=weight)
    knn.fit(trnX, trnY)
    pred = knn.predict(tstX)
    acc = metrics.accuracy_score(tstY, pred)
    accs.append(acc)
    cfm = metrics.confusion_matrix(tstY, pred, labels)
    print("\n2.2 KNN")
    print("a) Parameterization: \nAfter experimenting, the following parameters were used:\nMetric: *{}*\n"
          "Number of neighbours: *{}*\nWeight: *{}*".format(metric, n_neighbors, weight))
    print("b) Evaluation Metrics:\nAccuracy:{}\nConfusion Matrix:\n{}".format(acc, cfm))
    #######################################################################################################
    #Decision Tree
    splitter = "best"
    criterion = "entropy"
    max_depth = 25
    min_samples_leaf = 0.001

    tree = DecisionTreeClassifier(min_samples_leaf=min_samples_leaf, max_depth=max_depth, criterion=criterion,
                                  splitter=splitter, random_state=rs)
    tree.fit(trnX, trnY)
    pred = tree.predict(tstX)
    acc = metrics.accuracy_score(tstY, pred)
    accs.append(acc)
    cfm = metrics.confusion_matrix(tstY, pred, labels)
    print("\n2.3 Decision Tree")
    print("a) Parameterization: \nAfter experimenting, the following parameters were used:\nCriterion: *{}*\n"
          "Splitter: *{}*\nMax depth: *{}*\nMin samples leaf: *{}*"
          .format(criterion, splitter, max_depth, min_samples_leaf))
    print("b) Evaluation Metrics:\nAccuracy:{}\nConfusion Matrix:\n{}".format(acc, cfm))
    #######################################################################################################
    #Random Forest
    max_features = 0.3
    n_estimators = 550
    criterion = "entropy"
    max_depth = 25
    rf = RandomForestClassifier(n_estimators=n_estimators, max_depth=max_depth, max_features=max_features,
                                criterion=criterion, random_state=rs)
    rf.fit(trnX, trnY)
    pred = rf.predict(tstX)
    acc = metrics.accuracy_score(tstY, pred)
    accs.append(acc)
    cfm = metrics.confusion_matrix(tstY, pred, labels)
    print("\n2.4 Random Forest")
    print("b) Parameterization: \nAfter experimenting, the following parameters were used:\nCriterion: *{}*\n"
          "Max Features: *{}*\nNumber of estimators: *{}*"
          .format(criterion, max_features, n_estimators))
    print("b) Evaluation Metrics:\nAccuracy:{}\nConfusion Matrix:\n{}".format(acc, cfm))
    #######################################################################################################
    #Gradient Boosting
    loss = "deviance"
    lr = 0.3
    min_samples_leaf = 0.001
    n_estimators = 300
    max_depth = 25

    gb = GradientBoostingClassifier(min_samples_leaf=min_samples_leaf, n_estimators=n_estimators, loss=loss,
                                    learning_rate=lr, random_state=rs, max_depth=max_depth)
    gb.fit(trnX, trnY)
    pred = gb.predict(tstX)
    acc = metrics.accuracy_score(tstY, pred)
    accs.append(acc)
    cfm = metrics.confusion_matrix(tstY, pred, labels)
    print("\n2.5 Gradient Boosting")
    print("a) Parameterization: \nAfter experimenting, the following parameters were used:\nLoss: *{}*\n"
          "Learning Rate: *{}*\nMin Samples Leaf: *{}*\nNumber of estimators: *{}*\nMax depth: *{}*"
          .format(loss, lr, min_samples_leaf, n_estimators, max_depth))
    print("b) Evaluation Metrics:\nAccuracy:{}\nConfusion Matrix:\n{}".format(acc, cfm))

    #######################################################################################################

    print("\n3. Comparative Performance: NB|KNN|DT|RF|GB\nAccuracies:{}".format(accs))





