import pandas as pd
from sklearn import metrics
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB, BernoulliNB
from sklearn.tree import DecisionTreeClassifier
import datapreprocessing as datapp, evaluation as eval, plot

def preprocessing_statistics(df):
    data = df. copy()
    columns = ['Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology', 'Vertical_Distance_To_Hydrology'
        , 'Horizontal_Distance_To_Roadways', 'Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm',
               'Horizontal_Distance_To_Fire_Points',
               'y0','y1','y2','y3','y4','y5','y6','y7','y8','y9','y10','y11','y12','y13','y14','y15','y16','y17','y18',
               'y19','y20','y21','y22','y23','y24','y25','y26','y27','y28','y29','y30','y31','y32','y33','y34','y35',
               'y36','y37','y38','y39','y40','y41','y42','y43', 'Cover_Type']

    categoric = ['y0','y1','y2','y3','y4','y5','y6','y7','y8','y9','y10','y11','y12','y13','y14','y15','y16','y17','y18',
               'y19','y20','y21','y22','y23','y24','y25','y26','y27','y28','y29','y30','y31','y32','y33','y34','y35',
               'y36','y37','y38','y39','y40','y41','y42','y43']
    to_clf = 'Cover_Type'
    rs = 32
    accs=[]

    #Preprocessing decisions
    train_ratio = 0.7
    normalization = "standard"
    bal = "subsample"
    trnX, tstX, valX, trnY, tstY, valY = datapp.subsample_split(data, to_clf, categoric, normalization)
    trnY = trnY.astype("int")
    valY = valY.astype("int")
    tstY = tstY.astype("int")
    labels = pd.unique(data[to_clf].values).astype("int")

    ##########################################################################################

    norms = [None, "minmax", "standard"]
    classifiers = [BernoulliNB(), DecisionTreeClassifier(), RandomForestClassifier()]
    names = ["BernouliNB", "DecisionTree", "RandomForest"]

    accs = []
    for n in range(len(norms)):
        norm = norms[n]
        for clf in classifiers:
            trnX, tstX, valX, trnY, tstY, valY = datapp.subsample_split(data, to_clf, categoric, norm)
            tstY = tstY.astype("int")
            clf.fit(trnX, trnY.astype('int'))
            pred = clf.predict(tstX)
            acc = metrics.accuracy_score(tstY, pred)
            accs.append(acc)


    print("1. Normalization:\nVarious normalizations were tested using classifiers with default parameters.\n"
          "1.1 No normalization:\n{} accuracy:\t{}\n{} accuracy:\t{}\n{} accuracy:\t{}"
          "\n1.2 MinMax Normalization:\n"
          "{} accuracy:\t{}\n{} accuracy:\t{}\n{} accuracy:\t{}"
          "\n1.3 Standard Normalization:\n{} accuracy:\t{}\n{} accuracy:\t{}"
          "\n{} accuracy:\t{}\n"
          .format(names[0], accs[0],  names[1], accs[1] ,names[2], accs[2], names[0], accs[3],
                  names[1],accs[4],names[2],accs[5],names[0], accs[6], names[1],
                  accs[7],names[2],accs[8]))

    #####################################################################################


