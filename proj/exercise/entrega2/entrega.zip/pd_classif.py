from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
import datapreprocessing as datapp, evaluation as eval, plot
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier


def classification_statistics(df):
    data = df.copy()
    data = data.astype("float")
    data["id"] = data["id"].astype("int")
    to_clf = "class"
    categoric = ["gender", "id"]
    to_remove = ["id"]
    rs=32
    accs = []
    sensi = []

    #Preprocessing decisions:
    normalization = "standard"
    bal = "smote"

    print("1. Applied preprocessing to all classifiers:\nNormalization: *{}*.\nBalancing of the trainning "
          "sets using: *{}*.\n".format(normalization, bal))
    print("2. Classifiers:")
    #Naive Bayes Specific Preprocessing
    tr = 0.9
    f = "PCA"
    selectk = 1
    #print(df.shape)
    datared = datapp.preprocess_alt(data, "class", red_corr=True, tr=tr, n=5, normalization=normalization,
                                    ignore_classes=categoric, as_df=True)
    data2 = datapp.feature_reduction(datared, "class", ["class", "id"], n_features=selectk, alg=f)

    print("2.1 Naive Bayes")
    print("a) Specific preprocessing:\nReduction of all groups of variables with correlation superior "
          "to *{}* to 3 new variables representing the mean, median and std of the previous columns.\n"
          "Variable reduction of *{}* using the algorithm *{}*."
          .format( tr, selectk, f))

    print("b) Parameterization: \nAfter experimenting, the default parameterization was used with the Gaussian Naive"
          "Bayes.")
    #Trainning and prediction
    nb = GaussianNB()
    acc, sens, cfm, std_acc, std_sens = eval.train_predict_kfold(data2, "class", nb, bal=bal, std=True)
    accs.append(acc)
    sensi.append(sens)
    print("c) Evaluation Metrics:\nAccuracy: {} with Standard Deviation: {}\nSensitivity: {} with Standard Deviation: {}\nConfusion Matrix:\n{}"
          .format(acc, std_acc, sens, std_sens, cfm))

    #######################################################################################################

    #KNN Specific Preprocessing
    tr = 0.9
    f = "selectkbest"
    selectk = 1
    datared = datapp.preprocess_alt(data, "class", red_corr=True, tr=tr, n=5, normalization=normalization,
                                    ignore_classes=categoric, as_df=True)
    df = datapp.feature_reduction(datared, "class", ["class", "id"], n_features=selectk, alg=f)
    metric = "manhattan"
    n_neighbors = 1
    print("\n2.2 KNN")
    print("a) Specific preprocessing:\nReduction of all groups of variables with correlation superior "
          "to *{}* to 3 new variables representing the mean, median and std of the previous columns.\n"
          "Variable reduction of *{}* using the algorithm *{}*."
          .format( tr, selectk, f))
    print("b) Parameterization: \nAfter experimenting, the following parameters were used:\nMetric: *{}*\n"
          "Number of neighbours: *{}*".format(metric, n_neighbors))

    #Trainning and prediction
    knn = KNeighborsClassifier(n_neighbors=n_neighbors, metric=metric)
    acc, sens, cfm, std_acc, std_sens = eval.train_predict_kfold(df, "class", knn, bal=bal, std=True)
    accs.append(acc)
    sensi.append(sens)
    print("c) Evaluation Metrics:\nAccuracy: {} with Standard Deviation: {}\nSensitivity: {} with Standard Deviation: {}\nConfusion Matrix:\n{}"
          .format(acc, std_acc, sens, std_sens, cfm))

    #######################################################################################################

    #Decision Trees Specific Preprocessing
    tr = 0.95
    f = "selectkbest"
    selectk = 1
    criterion = "entropy"
    splitter = "best"
    max_depth = 25
    min_samples_leaf = .005
    datared = datapp.preprocess_alt(data, "class", red_corr=True, tr=tr, n=5, normalization=normalization,
                                    ignore_classes=categoric, as_df=True)
    df = datapp.feature_reduction(datared, "class", ["class", "id"], n_features=selectk, alg=f)

    print("\n2.3 Decision Trees")
    print("a) Specific preprocessing:\nReduction of all groups of variables with correlation superior "
          "to *{}* to 3 new variables representing the mean, median and std of the previous columns.\n"
          "Variable reduction of *{}* using the algorithm *{}*."
          .format( tr, selectk, f))
    print("b) Parameterization: \nAfter experimenting, the following parameters were used:\nCriterion: *{}*\n"
          "Splitter: *{}*\nMax depth: *{}*\nMin samples leaf: *{}*"
          .format(criterion, splitter, max_depth, min_samples_leaf))

    #Trainning and prediction
    tree = DecisionTreeClassifier(min_samples_leaf=min_samples_leaf, max_depth=max_depth, criterion=criterion,
                                  random_state=rs, splitter=splitter)
    acc, sens, cfm, std_acc, std_sens = eval.train_predict_kfold(df, "class", tree, bal=bal, std=True)
    accs.append(acc)
    sensi.append(sens)
    print("c) Evaluation Metrics:\nAccuracy: {} with Standard Deviation: {}\nSensitivity: {} with Standard Deviation: {}\nConfusion Matrix:\n{}"
          .format(acc, std_acc, sens, std_sens, cfm))


    #######################################################################################################

    #Random Forest Specific Preprocessing
    tr = 0.95
    f = "selectkbest"
    selectk = 0.6
    datared = datapp.preprocess_alt(data, "class", red_corr=True, tr=tr, n=5, normalization=normalization,
                                    ignore_classes=categoric, as_df=True)
    df = datapp.feature_reduction(datared, "class", ["class", "id"], n_features=selectk, alg=f)
    criterion = "entropy"
    max_features = "log2"
    min_samples_split = 4
    n_estimators = 50

    max_depth = 25
    print("\n2.4 RandomForest")
    print("a) Specific preprocessing:\nReduction of all groups of variables with correlation superior "
          "to *{}* to 3 new variables representing the mean, median and std of the previous columns.\n"
          "Variable reduction of *{}* using the algorithm *{}*."
          .format( tr, selectk, f))
    print("b) Parameterization: \nAfter experimenting, the following parameters were used:\nCriterion: *{}*\n"
          "Max Features: *{}*\nMin Samples Split: *{}*\nNumber of estimators: *{}*"
          .format(criterion, max_features, min_samples_split, n_estimators))
    #Trainning and prediction
    rf = RandomForestClassifier(n_estimators=n_estimators, max_depth=max_depth, max_features=max_features,
                                criterion=criterion, random_state=rs, min_samples_split=min_samples_split)

    acc, sens, cfm,std_acc, std_sens = eval.train_predict_kfold(df, "class", rf, bal=bal, std=True)
    accs.append(acc)
    sensi.append(sens)
    print("c) Evaluation Metrics:\nAccuracy: {} with Standard Deviation: {}\nSensitivity: {} with Standard Deviation: {}\nConfusion Matrix:\n{}"
          .format(acc, std_acc, sens, std_sens, cfm))

    #######################################################################################################

    #Gradient Boosting Specific Preprocessing
    tr = 0.9
    f = "selectkbest"
    selectk = 0.9
    loss = "exponential"
    lr = 0.3
    min_samples_leaf = 0.01
    n_estimators = 100
    max_depth = 3

    datared = datapp.preprocess_alt(data, "class", red_corr=True, tr=tr, n=5, normalization=normalization,
                                    ignore_classes=categoric, as_df=True)
    df = datapp.feature_reduction(datared, "class", ["class", "id"], n_features=selectk, alg=f)

    print("\n2.5 Gradient Boosting")
    print("a) Specific preprocessing:\nReduction of all groups of variables with correlation superior "
          "to *{}* to 3 new variables representing the mean, median and std of the previous columns.\n"
          "Variable reduction of *{}* using the algorithm *{}*."
          .format( tr, selectk, f))

    print("b) Parameterization: \nAfter experimenting, the following parameters were used:\nLoss: *{}*\n"
          "Learning Rate: *{}*\nMin Samples Leaf: *{}*\nNumber of estimators: *{}*\nMax depth: *{}*"
          .format(loss, lr, min_samples_leaf, n_estimators, max_depth))
    #Trainning and prediction
    gb = GradientBoostingClassifier(min_samples_leaf=min_samples_leaf, n_estimators=n_estimators, loss=loss,
                                    learning_rate=lr, random_state=rs, max_depth=max_depth)

    acc, sens, cfm, std_acc, std_sens = eval.train_predict_kfold(df, "class", gb, bal=bal, std=True)
    accs.append(acc)
    sensi.append(sens)
    print("c) Evaluation Metrics:\nAccuracy: {} with Standard Deviation: {}\nSensitivity: {} with Standard Deviation: {}\nConfusion Matrix:\n{}"
          .format(acc, std_acc, sens, std_sens, cfm))


    #######################################################################################################
    print("\n3. Comparative Performance: NB|KNN|DT|RF|GB\nAccuracies:{}\nSensitivities:{}".format(accs,sensi))


